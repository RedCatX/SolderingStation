1. Lucida_Sans_Unicode16h.foc
This is the original BitFontCreator (*.foc) file, which you can directly open in 
BitFontCreator Pro or Grayscale.

2. hello.txt
This is a characters pattern file, which is used to Enable the characters
quickly in "Characters Table" pane. To load the pattern file,
Font > Edit Characters Table... > Load Table
NOTE: you can make your own pattern file in any TEXT editor, and 
save it with Encoding: Unicode

3. General format folder
There are the converted C file (*.c) and Binary file (*.bin) in General format,
based on the above BitFontCreator (*.foc) file

4. Microchip format folder
There are the converted C file (*.c) and Binary file (*.bin) in Microchip format,
based on the above BitFontCreator (*.foc) file